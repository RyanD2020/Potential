"""All Claude API interaction lives here: generating the step-by-step plan,
and coaching the person through one step of it at a time.

Kept separate from the Streamlit UI so the prompting logic can be tested
or tuned on its own.
"""
from __future__ import annotations

import json
import re
from typing import Any, Dict, List

import anthropic

DEFAULT_MODEL = "claude-sonnet-5"

PLAN_SYSTEM_PROMPT = """You are an expert project coach. A person will describe a project or \
problem they need to complete on their own, optionally along with supporting documents for \
context. Your job is to break their project into a clear, realistic, step-by-step plan that \
THEY will carry out themselves — you are not going to do the work for them.

Return ONLY valid JSON (no markdown fences, no commentary) matching this exact shape:

{
  "project_title": "short descriptive title",
  "summary": "2-3 sentence summary of what this project involves and the overall approach",
  "phases": [
    {
      "title": "phase name",
      "goal": "what this phase accomplishes",
      "steps": [
        {
          "title": "step name",
          "description": "what to do in this step, written directly to the person",
          "why_it_matters": "why this step matters / what it unlocks",
          "self_check_questions": ["question to help them know they've done this step well", "..."]
        }
      ]
    }
  ]
}

Guidelines:
- Break the project into 2-5 phases, each with 2-5 concrete steps. Fewer, clearer steps beat many vague ones.
- Steps should be actionable and specific to THIS project and any supporting documents provided — avoid generic advice.
- Reference specifics from any supporting documents where relevant.
- Assume the person will do the actual work; your steps should set them up to succeed on their own.
"""

STEP_COACH_SYSTEM_TEMPLATE = """You are an expert project coach helping someone work through one \
step of their own project. You already helped create their overall plan. Your role now is to \
COACH them through this specific step — not to do the work for them.

Project: {project_title}
Project summary: {project_summary}

Current phase: {phase_title} — {phase_goal}
Current step: {step_title}
Step description: {step_description}
Why this step matters: {why_it_matters}

Supporting documents context (may be empty):
{docs_context}

How to coach:
- Ask clarifying questions before jumping to answers when it would help them think it through.
- Give frameworks, checklists, and examples rather than finished deliverables.
- If they're stuck, break the step into smaller sub-actions instead of doing it for them.
- If they explicitly ask you to just do it for them, you can help more directly, but first \
mention that a lighter-touch nudge might let them do it themselves.
- Keep responses focused and practical, not long lectures.
- Refer back to the supporting documents by name when relevant.
"""


def _extract_json(text: str) -> Dict[str, Any]:
    """Best-effort extraction of a JSON object from a model response, in
    case the model wraps it in markdown fences despite instructions."""
    cleaned = text.strip()
    cleaned = re.sub(r"^```(json)?", "", cleaned).strip()
    cleaned = re.sub(r"```$", "", cleaned).strip()
    return json.loads(cleaned)


def generate_plan(api_key: str, model: str, intake_text: str, docs_context: str) -> Dict[str, Any]:
    """Call Claude once to turn an intake description (+ optional supporting
    documents) into a structured, multi-phase step-by-step plan."""
    client = anthropic.Anthropic(api_key=api_key)

    user_content = f"Project description:\n{intake_text}"
    if docs_context:
        user_content += f"\n\nSupporting documents:\n{docs_context}"

    response = client.messages.create(
        model=model,
        max_tokens=4000,
        system=PLAN_SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_content}],
    )

    raw_text = "".join(block.text for block in response.content if block.type == "text")
    return _extract_json(raw_text)


def coach_step(
    api_key: str,
    model: str,
    project_title: str,
    project_summary: str,
    phase_title: str,
    phase_goal: str,
    step_title: str,
    step_description: str,
    why_it_matters: str,
    docs_context: str,
    chat_history: List[Dict[str, str]],
) -> str:
    """Call Claude for one turn of the coaching chat scoped to a single step.

    chat_history is the full back-and-forth for this step so far (including
    the latest user message), as a list of {"role", "content"} dicts.
    """
    client = anthropic.Anthropic(api_key=api_key)

    system_prompt = STEP_COACH_SYSTEM_TEMPLATE.format(
        project_title=project_title,
        project_summary=project_summary,
        phase_title=phase_title,
        phase_goal=phase_goal,
        step_title=step_title,
        step_description=step_description,
        why_it_matters=why_it_matters,
        docs_context=docs_context or "(none provided)",
    )

    response = client.messages.create(
        model=model,
        max_tokens=1500,
        system=system_prompt,
        messages=chat_history,
    )

    return "".join(block.text for block in response.content if block.type == "text")
